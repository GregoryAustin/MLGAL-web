# Autoencoder, and classifier that read FITS data #

Project for Honours Thesis at UCT 

Gregory Austin
ASTGRE002
u14039712@tuks.co.za
