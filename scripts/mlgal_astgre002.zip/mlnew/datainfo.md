column index 14 'xv' is the class
possible classes: 1, 2, 3, 4, 6, 7, 8, 9 (1 being most likely, 9 being least likely)
possibly just do binary ??? 
